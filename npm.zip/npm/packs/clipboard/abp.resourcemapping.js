﻿module.exports = {
    mappings: {
        "@node_modules/clipboard/dist/*.*": "@libs/clipboard/"
    }
}