﻿module.exports = {
    mappings: {
        "@node_modules/luxon/build/global/*.*": "@libs/luxon/"
    }
}