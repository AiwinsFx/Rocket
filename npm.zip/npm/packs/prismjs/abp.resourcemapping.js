﻿module.exports = {
    mappings: {
        "@node_modules/prismjs/**/*.*": "@libs/prismjs/"
    }
}