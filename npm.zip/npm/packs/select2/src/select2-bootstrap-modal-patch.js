/*
    https://select2.org/troubleshooting/common-problems
*/
$.fn.modal.Constructor.prototype._enforceFocus = function () { };