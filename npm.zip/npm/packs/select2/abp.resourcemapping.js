﻿module.exports = {
    mappings: {
        "@node_modules/select2/dist/css/select2.min.css": "@libs/select2/css/",
        "@node_modules/select2/dist/js/select2.min.js": "@libs/select2/js/",
        "@node_modules/select2/dist/js/select2.full.min.js": "@libs/select2/js/",
        "@node_modules/select2/dist/js/i18n/*.js": "@libs/select2/js/i18n/",
        "@node_modules/@rocket/select2/src/*.*": "@libs/select2/js/"
    }
}