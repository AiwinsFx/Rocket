﻿module.exports = {
    mappings: {
        "@node_modules/anchor-js/anchor.js": "@libs/anchor-js/"
    }
}