﻿module.exports = {
    mappings: {
        "@node_modules/chart.js/dist/*.*": "@libs/chart.js/"
    }
}