﻿module.exports = {
    mappings: {
        "@node_modules/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js": "@libs/bootstrap-datepicker/",
        "@node_modules/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css": "@libs/bootstrap-datepicker/",
        "@node_modules/bootstrap-datepicker/dist/css/bootstrap-datepicker.css.map": "@libs/bootstrap-datepicker/",
        "@node_modules/bootstrap-datepicker/dist/locales/*.*": "@libs/bootstrap-datepicker/locales/"
    }
}