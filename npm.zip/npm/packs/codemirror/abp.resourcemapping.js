﻿module.exports = {
    mappings: {
        "@node_modules/codemirror/lib/*.*": "@libs/codemirror/"
    }
}