﻿module.exports = {
    mappings: {
        "@node_modules/lodash/lodash.min.js": "@libs/lodash/"
    }
}