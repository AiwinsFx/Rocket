﻿module.exports = {
    mappings: {
        "@node_modules/markdown-it/dist/markdown-it.min.js": "@libs/markdown-it/"
    }
}