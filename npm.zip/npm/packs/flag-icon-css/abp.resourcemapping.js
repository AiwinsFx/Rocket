﻿module.exports = {
    mappings: {
        "@node_modules/flag-icon-css/css/*": "@libs/flag-icon-css/css",
        "@node_modules/flag-icon-css/flags/1x1/*": "@libs/flag-icon-css/flags/1x1"
    }
}