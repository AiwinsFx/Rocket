﻿module.exports = {
    mappings: {
        "@node_modules/@rocket/highlight.js/lib/highlight.pack.js": "@libs/highlight.js/",       
        "@node_modules/@rocket/highlight.js/lib/styles/*.*": "@libs/highlight.js/styles/"
    }
}