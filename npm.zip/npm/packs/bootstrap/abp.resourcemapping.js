﻿module.exports = {
    mappings: {
        "@node_modules/bootstrap/dist/css/bootstrap.css": "@libs/bootstrap/css/",
        "@node_modules/bootstrap/dist/js/bootstrap.bundle.js": "@libs/bootstrap/js/"
    }
}