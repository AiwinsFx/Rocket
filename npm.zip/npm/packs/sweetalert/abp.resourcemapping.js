﻿module.exports = {
    mappings: {
        "@node_modules/sweetalert/dist/*.*": "@libs/sweetalert/"
    }
}