﻿module.exports = {
    mappings: {
        "@node_modules/jquery-form/dist/jquery.form.min.js": "@libs/jquery-form/"
    }
}