﻿module.exports = {
    mappings: {
        "@node_modules/@fortawesome/fontawesome-free/css/all.css": "@libs/@fortawesome/fontawesome-free/css/",
        "@node_modules/@fortawesome/fontawesome-free/css/v4-shims.css": "@libs/@fortawesome/fontawesome-free/css/",
        "@node_modules/@fortawesome/fontawesome-free/webfonts/*.*": "@libs/@fortawesome/fontawesome-free/webfonts/"
    }
}