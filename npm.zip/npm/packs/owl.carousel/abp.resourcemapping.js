﻿module.exports = {
    mappings: {
        "@node_modules/owl.carousel/dist/**/*.*": "@libs/owl.carousel/"
    }
}