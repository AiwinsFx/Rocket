﻿module.exports = {
  mappings: {
    '@node_modules/@rocket/utils/dist/bundles/*.*': '@libs/rocket/utils/',
  },
};
