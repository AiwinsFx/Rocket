﻿module.exports = {
    mappings: {
        "@node_modules/popper.js/dist/umd/popper.min.js": "@libs/popper.js/"
    }
}