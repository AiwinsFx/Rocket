﻿module.exports = {
    mappings: {
        "@node_modules/datatables.net/js/jquery.dataTables.js": "@libs/datatables.net/js/"
    }
}