﻿module.exports = {
    mappings: {
        "@node_modules/jquery/dist/jquery.js": "@libs/jquery/",
        "@node_modules/@rocket/jquery/src/*.*": "@libs/rocket/jquery/"
    }
}