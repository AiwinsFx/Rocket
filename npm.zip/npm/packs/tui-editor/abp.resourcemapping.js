﻿module.exports = {
    mappings: {
        "@node_modules/to-mark/dist/to-mark.min.js": "@libs/to-mark/",
        "@node_modules/tui-code-snippet/dist/*.*": "@libs/tui-code-snippet/",
        "@node_modules/squire-rte/build/squire.js": "@libs/squire-rte/",
        "@node_modules/tui-editor/dist/*.*": "@libs/tui-editor/"
    }
}