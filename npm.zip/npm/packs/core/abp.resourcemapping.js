﻿module.exports = {
    mappings: {
        "@node_modules/@rocket/core/src/*": "@libs/rocket/core/"
    }
}