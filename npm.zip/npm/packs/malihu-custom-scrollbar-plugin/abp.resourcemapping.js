﻿module.exports = {
    mappings: {
        "@node_modules/malihu-custom-scrollbar-plugin/*.*": "@libs/malihu-custom-scrollbar-plugin/"
    }
}