﻿module.exports = {
    mappings: {
        "@node_modules/toastr/build/*.*": "@libs/toastr/"
    }
}