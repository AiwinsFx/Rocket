import 'jest-preset-angular';
import 'jest-canvas-mock';
