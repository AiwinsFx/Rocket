# @rocket/ng.setting-management.config

[docs.rocket.io](https://docs.rocket.io)
