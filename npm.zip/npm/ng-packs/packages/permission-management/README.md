<h1> @rocket/ng.permission-management </h1>

[docs.rocket.io](https://docs.rocket.io)
