export * from './lib/services/identity-config.service';
export * from './lib/identity-config.module';
