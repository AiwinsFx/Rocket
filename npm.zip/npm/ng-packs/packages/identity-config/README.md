# @rocket/ng.identity.config

[docs.rocket.io](https://docs.rocket.io)
