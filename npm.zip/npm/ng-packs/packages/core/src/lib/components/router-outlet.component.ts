import { Component } from '@angular/core';

@Component({
  selector: 'rocket-router-outlet',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class RouterOutletComponent {}
