export const enum eLayoutType {
  account = 'account',
  application = 'application',
  empty = 'empty',
}
