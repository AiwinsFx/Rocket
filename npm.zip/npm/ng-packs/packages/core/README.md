<h1> @rocket/ng.core </h1>

[docs.rocket.io](https://docs.rocket.io)
