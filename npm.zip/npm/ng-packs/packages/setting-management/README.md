<h1> @rocket/ng.setting-management </h1>

[docs.rocket.io](https://docs.rocket.io)
