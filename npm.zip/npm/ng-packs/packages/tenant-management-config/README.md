# @rocket/ng.tenant-management.config

[docs.rocket.io](https://docs.rocket.io)
