export * from './lib/services/tenant-management-config.service';
export * from './lib/tenant-management-config.module';
